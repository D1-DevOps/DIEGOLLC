/**
 * Quitou Fácil - Professional JavaScript
 * Enhanced functionality with performance optimizations
 */

// Configuration
const CONFIG = {
    whatsapp: {
        phoneNumber: "5511999999999", // Substitua pelo número real
        defaultMessage: "Olá! Gostaria de negociar minha dívida e conseguir um desconto. Podem me ajudar?"
    },
    animations: {
        scrollThreshold: 150,
        debounceDelay: 100
    },
    analytics: {
        enabled: true,
        events: {
            CTA_CLICK: 'cta_click',
            FAQ_OPEN: 'faq_open',
            SCROLL_MILESTONE: 'scroll_milestone'
        }
    }
};

// Utility Functions
const Utils = {
    // Debounce function for performance optimization
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Throttle function for scroll events
    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    // Check if element is in viewport
    isInViewport(element, threshold = 0) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= -threshold &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) + threshold &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    },

    // Format phone number for WhatsApp
    formatPhoneNumber(phone) {
        return phone.replace(/\D/g, '');
    },

    // Generate tracking ID for analytics
    generateTrackingId() {
        return 'track_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
};

// Analytics Module
const Analytics = {
    track(event, data = {}) {
        if (!CONFIG.analytics.enabled) return;
        
        const eventData = {
            event,
            timestamp: new Date().toISOString(),
            url: window.location.href,
            userAgent: navigator.userAgent,
            ...data
        };

        // Log to console for development
        console.log('Analytics Event:', eventData);

        // Here you would send to your analytics service
        // Example: gtag('event', event, data);
        // Example: fbq('track', event, data);
    }
};

// WhatsApp Integration Module
const WhatsApp = {
    open(customMessage = null) {
        const phoneNumber = Utils.formatPhoneNumber(CONFIG.whatsapp.phoneNumber);
        const message = customMessage || CONFIG.whatsapp.defaultMessage;
        const encodedMessage = encodeURIComponent(message);
        const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
        
        // Track the event
        Analytics.track(CONFIG.analytics.events.CTA_CLICK, {
            source: 'whatsapp_button',
            message: message.substring(0, 50) + '...'
        });
        
        // Open WhatsApp
        window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    },

    // Generate custom message based on user interaction
    generateCustomMessage(source) {
        const messages = {
            hero: "Olá! Vi o site de vocês e gostaria de negociar minha dívida. Podem me ajudar com um desconto?",
            benefits: "Olá! Estou interessado nos benefícios que vocês oferecem para negociação de dívidas. Podem me atender?",
            testimonials: "Olá! Vi os depoimentos no site e fiquei interessado. Gostaria de saber mais sobre a negociação.",
            steps: "Olá! Quero entender melhor como funciona o processo de negociação de dívidas.",
            cases: "Olá! Vi os casos de sucesso e gostaria de uma proposta para minha situação.",
            final_cta: "Olá! Estou pronto para começar a negociação da minha dívida. Vamos conversar?"
        };
        
        return messages[source] || CONFIG.whatsapp.defaultMessage;
    }
};

// FAQ Module
const FAQ = {
    init() {
        const faqItems = document.querySelectorAll('.faq__item');
        faqItems.forEach(item => {
            const question = item.querySelector('.faq__question');
            if (question) {
                question.addEventListener('click', (e) => this.toggle(e.currentTarget));
            }
        });
    },

    toggle(questionElement) {
        const faqItem = questionElement.parentElement;
        const answer = faqItem.querySelector('.faq__answer');
        const toggle = questionElement.querySelector('.faq__toggle');
        
        if (!answer || !toggle) return;

        // Close all other FAQ items
        this.closeAll(faqItem);
        
        // Toggle current FAQ item
        const isActive = answer.classList.contains('active');
        
        if (isActive) {
            this.close(answer, toggle);
        } else {
            this.open(answer, toggle, questionElement.textContent.trim());
        }
    },

    open(answer, toggle, question) {
        answer.classList.add('active');
        toggle.textContent = '−';
        toggle.style.transform = 'rotate(180deg)';
        
        // Track FAQ interaction
        Analytics.track(CONFIG.analytics.events.FAQ_OPEN, {
            question: question.substring(0, 50) + '...'
        });
    },

    close(answer, toggle) {
        answer.classList.remove('active');
        toggle.textContent = '+';
        toggle.style.transform = 'rotate(0deg)';
    },

    closeAll(excludeItem = null) {
        const allFaqItems = document.querySelectorAll('.faq__item');
        allFaqItems.forEach(item => {
            if (item !== excludeItem) {
                const answer = item.querySelector('.faq__answer');
                const toggle = item.querySelector('.faq__toggle');
                if (answer && toggle) {
                    this.close(answer, toggle);
                }
            }
        });
    }
};

// Scroll Animations Module
const ScrollAnimations = {
    elements: [],
    
    init() {
        this.elements = document.querySelectorAll('.animate-on-scroll');
        this.bindEvents();
        this.checkAnimations(); // Run once on load
    },

    bindEvents() {
        const throttledCheck = Utils.throttle(() => this.checkAnimations(), 100);
        window.addEventListener('scroll', throttledCheck);
        window.addEventListener('resize', Utils.debounce(() => this.checkAnimations(), 250));
    },

    checkAnimations() {
        this.elements.forEach(element => {
            if (Utils.isInViewport(element, CONFIG.animations.scrollThreshold)) {
                this.animateElement(element);
            }
        });
    },

    animateElement(element) {
        if (!element.classList.contains('animated')) {
            element.classList.add('animated');
            
            // Add staggered animation delay for grouped elements
            const siblings = element.parentElement.querySelectorAll('.animate-on-scroll');
            const index = Array.from(siblings).indexOf(element);
            element.style.animationDelay = `${index * 0.1}s`;
        }
    }
};

// Header Module
const Header = {
    init() {
        this.header = document.getElementById('header');
        if (this.header) {
            this.bindEvents();
        }
    },

    bindEvents() {
        const throttledScroll = Utils.throttle(() => this.handleScroll(), 100);
        window.addEventListener('scroll', throttledScroll);
    },

    handleScroll() {
        const scrollY = window.scrollY;
        
        if (scrollY > 100) {
            this.header.style.background = 'rgba(255, 255, 255, 0.98)';
            this.header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            this.header.style.background = 'rgba(255, 255, 255, 0.95)';
            this.header.style.boxShadow = 'none';
        }
    }
};

// Smooth Scroll Module
const SmoothScroll = {
    init() {
        const links = document.querySelectorAll('a[href^="#"]');
        links.forEach(link => {
            link.addEventListener('click', (e) => this.handleClick(e));
        });
    },

    handleClick(e) {
        e.preventDefault();
        const targetId = e.currentTarget.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            const headerHeight = document.getElementById('header')?.offsetHeight || 0;
            const targetPosition = targetElement.offsetTop - headerHeight - 20;
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    }
};

// CTA Buttons Enhancement
const CTAButtons = {
    init() {
        const buttons = document.querySelectorAll('.btn');
        buttons.forEach(button => {
            this.enhanceButton(button);
        });
    },

    enhanceButton(button) {
        // Add loading state functionality
        button.addEventListener('click', (e) => {
            if (button.onclick && button.onclick.toString().includes('openWhatsApp')) {
                this.addLoadingState(button);
            }
        });

        // Add hover effects
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'translateY(-2px) scale(1.02)';
        });

        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translateY(0) scale(1)';
        });
    },

    addLoadingState(button) {
        const originalText = button.innerHTML;
        button.innerHTML = '<span class="btn--icon">⏳</span> Redirecionando...';
        button.style.opacity = '0.8';
        button.disabled = true;
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.style.opacity = '1';
            button.disabled = false;
        }, 2000);
    }
};

// Performance Monitor
const Performance = {
    init() {
        this.measurePageLoad();
        this.trackScrollMilestones();
    },

    measurePageLoad() {
        window.addEventListener('load', () => {
            const loadTime = performance.now();
            Analytics.track('page_load', {
                load_time: Math.round(loadTime),
                performance_rating: loadTime < 2000 ? 'excellent' : loadTime < 4000 ? 'good' : 'needs_improvement'
            });
        });
    },

    trackScrollMilestones() {
        const milestones = [25, 50, 75, 100];
        let trackedMilestones = new Set();

        const throttledScroll = Utils.throttle(() => {
            const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
            
            milestones.forEach(milestone => {
                if (scrollPercent >= milestone && !trackedMilestones.has(milestone)) {
                    trackedMilestones.add(milestone);
                    Analytics.track(CONFIG.analytics.events.SCROLL_MILESTONE, {
                        milestone: milestone
                    });
                }
            });
        }, 500);

        window.addEventListener('scroll', throttledScroll);
    }
};

// Global Functions (for backward compatibility)
window.openWhatsApp = function(source = 'default') {
    const customMessage = WhatsApp.generateCustomMessage(source);
    WhatsApp.open(customMessage);
};

window.toggleFaq = function(element) {
    FAQ.toggle(element);
};

// Main Application
const App = {
    init() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.start());
        } else {
            this.start();
        }
    },

    start() {
        console.log('🚀 Quitou Fácil - Professional Version Loaded');
        
        // Initialize all modules
        Header.init();
        FAQ.init();
        ScrollAnimations.init();
        SmoothScroll.init();
        CTAButtons.init();
        Performance.init();

        // Add custom event listeners
        this.addCustomEventListeners();
        
        // Track page view
        Analytics.track('page_view', {
            page: 'landing_page',
            version: 'professional'
        });
    },

    addCustomEventListeners() {
        // Track section visibility
        const sections = document.querySelectorAll('section[id]');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    Analytics.track('section_view', {
                        section: entry.target.id
                    });
                }
            });
        }, { threshold: 0.5 });

        sections.forEach(section => observer.observe(section));

        // Add keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                FAQ.closeAll();
            }
        });

        // Add form validation if forms exist
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => this.handleFormSubmit(e));
        });
    },

    handleFormSubmit(e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);
        
        // Basic validation
        let isValid = true;
        const requiredFields = form.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('error');
            } else {
                field.classList.remove('error');
            }
        });

        if (isValid) {
            Analytics.track('form_submit', {
                form_id: form.id || 'unknown',
                fields: Object.fromEntries(formData)
            });
            
            // Here you would normally send the form data to your server
            console.log('Form submitted:', Object.fromEntries(formData));
        }
    }
};

// Initialize the application
App.init();

// Export for testing purposes
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { App, Utils, Analytics, WhatsApp, FAQ };
}


// Calculator functionality
const Calculator = {
    discountRates: {
        'personal-loan': { '1-3': 0.3, '4-6': 0.5, '7-12': 0.7, '12+': 0.85 },
        'credit-card': { '1-3': 0.4, '4-6': 0.6, '7-12': 0.75, '12+': 0.9 },
        'vehicle-financing': { '1-3': 0.25, '4-6': 0.45, '7-12': 0.65, '12+': 0.8 },
        'real-estate': { '1-3': 0.15, '4-6': 0.3, '7-12': 0.5, '12+': 0.7 },
        'overdraft': { '1-3': 0.5, '4-6': 0.7, '7-12': 0.8, '12+': 0.9 },
        'other': { '1-3': 0.3, '4-6': 0.5, '7-12': 0.7, '12+': 0.8 }
    },

    init() {
        const form = document.getElementById('calculator-form');
        if (form) {
            form.addEventListener('submit', (e) => this.handleSubmit(e));
        }
    },

    handleSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const debtAmount = parseFloat(formData.get('debtAmount'));
        const debtType = formData.get('debtType');
        const timeOverdue = formData.get('timeOverdue');

        if (this.validateInputs(debtAmount, debtType, timeOverdue)) {
            this.calculateAndShow(debtAmount, debtType, timeOverdue);
        }
    },

    validateInputs(amount, type, time) {
        if (!amount || amount < 100) {
            alert('Por favor, insira um valor válido para a dívida (mínimo R$ 100)');
            return false;
        }
        if (!type) {
            alert('Por favor, selecione o tipo de dívida');
            return false;
        }
        if (!time) {
            alert('Por favor, selecione há quanto tempo está em atraso');
            return false;
        }
        return true;
    },

    calculateAndShow(amount, type, time) {
        const discountRate = this.discountRates[type][time];
        const discountAmount = amount * discountRate;
        const negotiatedAmount = amount - discountAmount;
        const discountPercentage = Math.round(discountRate * 100);

        // Update result display
        document.getElementById('original-amount').textContent = this.formatCurrency(amount);
        document.getElementById('negotiated-amount').textContent = this.formatCurrency(negotiatedAmount);
        document.getElementById('total-savings').textContent = this.formatCurrency(discountAmount);
        document.getElementById('discount-percentage').textContent = discountPercentage + '%';

        // Show result
        const resultDiv = document.getElementById('calculator-result');
        resultDiv.style.display = 'block';
        resultDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });

        // Track calculation
        Analytics.track('calculator_used', {
            debt_amount: amount,
            debt_type: type,
            time_overdue: time,
            estimated_savings: discountAmount,
            discount_percentage: discountPercentage
        });
    },

    formatCurrency(value) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value);
    }
};

// Contact Form functionality
const ContactForm = {
    init() {
        const contactForm = document.getElementById('contact-form');
        const newsletterForm = document.getElementById('newsletter-form');
        
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => this.handleContactSubmit(e));
        }
        
        if (newsletterForm) {
            newsletterForm.addEventListener('submit', (e) => this.handleNewsletterSubmit(e));
        }

        // Phone mask
        const phoneInput = document.getElementById('contact-phone');
        if (phoneInput) {
            phoneInput.addEventListener('input', this.formatPhone);
        }
    },

    handleContactSubmit(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        
        // Validate form
        if (!this.validateContactForm(form)) {
            return;
        }

        // Show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<span class="btn--icon">⏳</span> Enviando...';
        submitBtn.disabled = true;

        // Simulate form submission (replace with actual API call)
        setTimeout(() => {
            this.showMessage('success');
            form.reset();
            
            // Track form submission
            Analytics.track('contact_form_submit', {
                subject: formData.get('subject'),
                debt_value: formData.get('debtValue') || 'not_provided'
            });

            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }, 2000);
    },

    handleNewsletterSubmit(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const email = formData.get('email');

        if (!this.validateEmail(email)) {
            alert('Por favor, insira um e-mail válido.');
            return;
        }

        // Show loading state
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Inscrevendo...';
        submitBtn.disabled = true;

        // Simulate newsletter subscription
        setTimeout(() => {
            alert('✅ Inscrição realizada com sucesso! Você receberá nossas dicas financeiras.');
            form.reset();
            
            // Track newsletter subscription
            Analytics.track('newsletter_subscribe', {
                email: email
            });

            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }, 1500);
    },

    validateContactForm(form) {
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                this.showFieldError(field, 'Este campo é obrigatório');
                isValid = false;
            } else {
                this.clearFieldError(field);
                
                // Specific validations
                if (field.type === 'email' && !this.validateEmail(field.value)) {
                    this.showFieldError(field, 'E-mail inválido');
                    isValid = false;
                }
                
                if (field.type === 'tel' && !this.validatePhone(field.value)) {
                    this.showFieldError(field, 'Telefone inválido');
                    isValid = false;
                }
            }
        });

        return isValid;
    },

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    validatePhone(phone) {
        const phoneRegex = /^\(\d{2}\)\s\d{4,5}-\d{4}$/;
        return phoneRegex.test(phone);
    },

    formatPhone(e) {
        let value = e.target.value.replace(/\D/g, '');
        
        if (value.length <= 11) {
            if (value.length <= 2) {
                value = value.replace(/(\d{0,2})/, '($1');
            } else if (value.length <= 6) {
                value = value.replace(/(\d{2})(\d{0,4})/, '($1) $2');
            } else if (value.length <= 10) {
                value = value.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
            } else {
                value = value.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
            }
        }
        
        e.target.value = value;
    },

    showFieldError(field, message) {
        field.classList.add('error');
        
        // Remove existing error message
        const existingError = field.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
        
        // Add new error message
        const errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.style.color = 'var(--secondary-red)';
        errorDiv.style.fontSize = 'var(--text-sm)';
        errorDiv.style.marginTop = 'var(--space-1)';
        errorDiv.textContent = message;
        
        field.parentNode.appendChild(errorDiv);
    },

    clearFieldError(field) {
        field.classList.remove('error');
        const errorDiv = field.parentNode.querySelector('.field-error');
        if (errorDiv) {
            errorDiv.remove();
        }
    },

    showMessage(type) {
        // Hide all messages first
        const successDiv = document.getElementById('form-success');
        const errorDiv = document.getElementById('form-error');
        
        if (successDiv) successDiv.style.display = 'none';
        if (errorDiv) errorDiv.style.display = 'none';
        
        // Show the appropriate message
        const messageId = type === 'success' ? 'form-success' : 'form-error';
        const messageDiv = document.getElementById(messageId);
        if (messageDiv) {
            messageDiv.style.display = 'block';
            messageDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
};

// Update the App.start method to include new modules
const originalStart = App.start;
App.start = function() {
    originalStart.call(this);
    
    // Initialize new modules
    Calculator.init();
    ContactForm.init();
};

